import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ImageBackground, StyleSheet } from 'react-native';

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showErrorMessage, setShowErrorMessage] = useState(false);
  const [loginAttempts, setLoginAttempts] = useState(0);

  const handleLogin = () => {
    // Add authentication logic here
    if (username === 'admin' && password === 'password') {
      navigation.navigate('MainScreen');
    } else {
      setShowErrorMessage(true);
      setLoginAttempts(prevAttempts => prevAttempts + 1);
    }
  };

  const handleCancel = () => {
    setUsername('');
    setPassword('');
    setShowErrorMessage(false);
    setLoginAttempts(0);
  };

  const handleSignupNow = () => {
    navigation.navigate('SignupScreen');
  };

  return (
    <ImageBackground
      source={require('./assets/pharmacy_background.jpg')}
      style={styles.backgroundImage}
    >
      <View style={styles.container}>
        <Text style={styles.title}>Welcome to Pharmacy Management</Text>
        <View style={[styles.inputContainer, showErrorMessage && styles.errorContainer]}>
          <TextInput
            style={styles.input}
            placeholder="Username"
            value={username}
            onChangeText={text => setUsername(text)}
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            secureTextEntry={true}
            onChangeText={text => setPassword(text)}
          />
          {showErrorMessage && <Text style={styles.errorMessage}>Incorrect Password</Text>}
          {loginAttempts >= 2 && (
            <TouchableOpacity onPress={() => console.log("Forget Password")}>
              <Text style={[styles.signUpText, styles.underlinedText]}>Forget Password</Text>
            </TouchableOpacity>
          )}
        </View>
        <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
          <Text style={styles.buttonText}>Login</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
          <Text style={styles.buttonText}>Cancel</Text>
        </TouchableOpacity>
        <View style={styles.signUpContainer}>
          <Text style={styles.signUpText}>New user? </Text>
          <TouchableOpacity onPress={handleSignupNow}>
            <Text style={[styles.signUpText, styles.underlinedText]}>Sign up now</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
  flex: 1,
  resizeMode: 'cover',
  justifyContent: 'center',
  alignItems: 'center',
  width: '100%', // Adjust width as needed
  height: '50%', // Adjust height as needed
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#072dee',
    marginBottom: 30,
    textAlign: 'center',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 10,
  },
  inputContainer: {
    marginBottom: 20,
  },
  input: {
    width: 300,
    height: 40,
    borderWidth: 1,
    borderColor: '#87CEEB', // Light blue color
    borderRadius: 5,
    backgroundColor: '#fff',
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  
  loginButton: {
    width: 300,
    height: 40,
    backgroundColor: '#43ed64',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    marginBottom: 10,
  },
  cancelButton: {
    width: 300,
    height: 40,
    backgroundColor: '#dc3545',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  signUpContainer: {
    flexDirection: 'row',
  },
  signUpText: {
    color: '#7f8ccb',
    fontSize: 16,
  },
  underlinedText: {
    color: '#43ed64',
    textDecorationLine: 'underline',
  },
  errorMessage: {
    color: 'red',
    marginBottom: 10,
  },
});

export default LoginScreen;
